<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d7242cc2             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
