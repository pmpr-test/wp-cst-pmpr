<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ad16e1a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Widget; use Pmpr\Common\Foundation\Widget; abstract class Common extends Widget { }
