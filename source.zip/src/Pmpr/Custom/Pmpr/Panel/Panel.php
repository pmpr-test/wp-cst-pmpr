<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6c5be060             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Panel; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function __construct() { $this->name = "\155\157\144\165\x6c\x65"; parent::__construct(); } public function gigwcakmiyayoigw() { } public function sqwgomwcqysewuks() : array { return [$this->oeuiuocwuggewqmk($this->aakmagwggmkoiiyu())->faioisokmmaeimoo()->jyumyyugiwwiqomk(100)->gswweykyogmsyawy(__("\x4d\157\144\x75\x6c\145\x73", PR__CST__PMPR))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)]; } }
