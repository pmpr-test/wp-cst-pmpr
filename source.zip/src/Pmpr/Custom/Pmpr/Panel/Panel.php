<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc70301e1d7             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Panel; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function __construct() { $this->name = 'module'; parent::__construct(); } public function gigwcakmiyayoigw() { } public function sqwgomwcqysewuks($mkucggyaiaukqoce) : array { return [$this->oeuiuocwuggewqmk($this->aakmagwggmkoiiyu())->faioisokmmaeimoo()->jyumyyugiwwiqomk(100)->gswweykyogmsyawy(__('Modules', PR__CST__PMPR))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)]; } }
