<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a86ce00b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Panel; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\Panel\AbstractPanel; class Panel extends AbstractPanel { public function __construct() { $this->name = "\x6d\x6f\144\165\154\145"; parent::__construct(); } public function gigwcakmiyayoigw() { } public function sqwgomwcqysewuks() : array { return [$this->oeuiuocwuggewqmk($this->aakmagwggmkoiiyu())->faioisokmmaeimoo()->jyumyyugiwwiqomk(100)->gswweykyogmsyawy(__("\x4d\x6f\144\165\154\x65\163", PR__CST__PMPR))->saemoowcasogykak(IconInterface::csoyqymugwqiggki)]; } }
