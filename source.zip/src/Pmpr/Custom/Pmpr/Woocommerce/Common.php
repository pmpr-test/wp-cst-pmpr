<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7826d11c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Woocommerce; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Common extends Container { public function aqasygcsqysmmyke() : int { $product = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->ayueggmoqeeukqmq(Constants::kqigmeickowqiiyy); if ($product) { goto kocqqoyymosmuksu; } $product = $this->caokeucsksukesyo()->aqasygcsqysmmyke()->iooowgsqoyqseyuu(); kocqqoyymosmuksu: return absint($product); } }
