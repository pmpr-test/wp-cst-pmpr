<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5eaefc02             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Ticket; use Pmpr\Custom\Pmpr\Container; abstract class Common extends Container { }
