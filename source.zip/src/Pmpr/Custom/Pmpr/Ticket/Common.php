<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6fea98df             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Ticket; use Pmpr\Custom\Pmpr\Container; abstract class Common extends Container { }
