<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fe5bca37             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Ticket; use Pmpr\Custom\Pmpr\Container; abstract class Common extends Container { }
