<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7826d11c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\x78\157\156\x6f\x6d\171\x5f\x73\x69\x6e\147\154\145\x5f\x76\x61\154\x75\145\x5f\155\x6f\144\151\146\171\137\x69\x74\145\x6d\163", [$this, "\163\143\157\x61\171\141\155\x75\171\x71\147\153\143\x61\x6d\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
