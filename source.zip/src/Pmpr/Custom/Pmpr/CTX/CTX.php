<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5eaefc02             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\164\x61\x78\157\x6e\x6f\x6d\171\x5f\163\151\156\147\x6c\x65\x5f\166\x61\x6c\165\x65\x5f\x6d\157\x64\x69\146\x79\137\151\x74\x65\155\163", [$this, "\x73\143\x6f\x61\171\x61\x6d\165\x79\x71\147\x6b\x63\141\155\x67"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
