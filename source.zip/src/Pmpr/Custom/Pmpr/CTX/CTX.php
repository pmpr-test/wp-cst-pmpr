<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d000c42857             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CTX; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class CTX extends Container { public function mameiwsayuyquoeq() { PostLevel::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x74\141\x78\x6f\x6e\x6f\x6d\171\x5f\x73\x69\156\x67\x6c\x65\x5f\166\141\x6c\x75\145\x5f\x6d\157\144\151\x66\x79\x5f\x69\164\145\155\x73", [$this, "\163\143\157\x61\x79\x61\155\165\171\161\x67\153\x63\141\155\147"]); parent::wigskegsqequoeks(); } public function scoayamuyqgkcamg($oammesyieqmwuwyi = []) { $oammesyieqmwuwyi[] = Constants::cmckeoksigiaqykc; $oammesyieqmwuwyi[] = Constants::qgciomgukmcwscqw; return $oammesyieqmwuwyi; } }
