<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda1c00115f             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\CPT; use Pmpr\Custom\Pmpr\Container; class CPT extends Container { public function mameiwsayuyquoeq() { News::symcgieuakksimmu(); Service::symcgieuakksimmu(); Technology::symcgieuakksimmu(); SuccessStory::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->cecaguuoecmccuse('post_thumbnail_html', [$this, 'kcqeiygygweoymwk'], 0, 5)->cecaguuoecmccuse('wp_get_attachment_image', [$this, 'kcqeiygygweoymwk'], 0, 5); parent::kgquecmsgcouyaya(); } public function kcqeiygygweoymwk($nsmgceoqaqogqmuw, $post, $aiooqyausygaasqm, $oiegiwogmwmawkeo, $wwgucssaecqekuek = []) { if (!$nsmgceoqaqogqmuw && $post) { $seumokooiykcomco = $this->caokeucsksukesyo()->ayueggmoqeeukqmq(); $wkaqekwwgqsqwcoi = $seumokooiykcomco->igawqaomowicuayw(Common::oomeqcwgcuseimeg, $post, true); $qwekmgewkeeegomi = $seumokooiykcomco->igawqaomowicuayw(Common::gsciggmwkagcscik, $post, true); if ($wkaqekwwgqsqwcoi) { $nsmgceoqaqogqmuw = $this->ocksiywmkyaqseou('icon_html_filter', $wkaqekwwgqsqwcoi, $wwgucssaecqekuek, $qwekmgewkeeegomi, $oiegiwogmwmawkeo); } } return $nsmgceoqaqogqmuw; } }
