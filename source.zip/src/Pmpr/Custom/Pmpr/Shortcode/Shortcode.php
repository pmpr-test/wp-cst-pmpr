<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c620a234d             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\141\156\x63\x65\x64\x2d\x63\155\x73"))) { goto foeeqckqsyockkak; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\145\x67\x69\163\164\x65\x72\x5f\x73\150\157\162\x74\143\157\x64\x65\163", [$this, "\162\x65\147\151\163\x74\x65\162"]); foeeqckqsyockkak: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
