<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a99acd768e             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if ($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->gsaceacmqiuqoouo("\x61\144\166\x61\156\143\145\144\55\x63\155\163", Constants::wcwmcocqaeiwwuss)) { $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\x65\147\151\163\x74\x65\x72\137\x73\x68\157\162\x74\143\157\144\x65\x73", [$this, "\162\x65\x67\x69\x73\164\145\x72"]); } } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
