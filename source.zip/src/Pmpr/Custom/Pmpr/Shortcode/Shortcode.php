<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec301a229             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\141\156\143\145\x64\55\143\155\x73"))) { goto iesekaeqeomeuaui; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\x72\x65\147\x69\163\164\x65\162\137\163\150\157\162\x74\143\x6f\144\x65\163", [$this, "\x72\145\x67\x69\163\x74\x65\x72"]); iesekaeqeomeuaui: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
