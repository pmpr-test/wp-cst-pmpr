<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7826d11c             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\144\x76\141\x6e\x63\x65\144\55\143\x6d\x73"))) { goto iesekaeqeomeuaui; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\145\x67\x69\x73\x74\x65\162\137\163\150\157\162\x74\143\x6f\x64\x65\163", [$this, "\162\145\x67\x69\x73\x74\x65\x72"]); iesekaeqeomeuaui: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
