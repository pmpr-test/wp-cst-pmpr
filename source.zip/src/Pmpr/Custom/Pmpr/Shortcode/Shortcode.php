<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f43a86ce00b             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\x64\x76\141\x6e\x63\x65\144\x2d\143\x6d\x73"))) { goto foeeqckqsyockkak; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\x65\x67\151\163\x74\145\x72\x5f\163\150\x6f\162\x74\143\x6f\144\x65\x73", [$this, "\x72\x65\x67\x69\x73\x74\145\162"]); foeeqckqsyockkak: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
