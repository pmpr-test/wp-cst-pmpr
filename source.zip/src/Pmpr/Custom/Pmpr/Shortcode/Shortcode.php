<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517558c138             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->gsaceacmqiuqoouo("\141\144\x76\x61\x6e\x63\145\144\x2d\143\x6d\163", Constants::wcwmcocqaeiwwuss))) { goto foeeqckqsyockkak; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\137\162\145\147\151\163\164\145\162\x5f\x73\x68\x6f\162\x74\143\x6f\144\x65\163", [$this, "\162\145\147\151\x73\x74\145\162"]); foeeqckqsyockkak: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
