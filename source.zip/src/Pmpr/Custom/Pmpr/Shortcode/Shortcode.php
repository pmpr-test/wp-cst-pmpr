<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ad16e1a             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\x61\x64\166\x61\156\143\x65\144\55\x63\x6d\163"))) { goto iesekaeqeomeuaui; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\x65\x67\x69\163\164\x65\x72\x5f\163\x68\157\162\x74\x63\157\144\145\x73", [$this, "\162\145\x67\151\x73\164\145\162"]); iesekaeqeomeuaui: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
