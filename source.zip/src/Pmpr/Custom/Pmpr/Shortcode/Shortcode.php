<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d000c42857             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if ($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->gsaceacmqiuqoouo("\141\x64\x76\x61\x6e\143\x65\144\x2d\143\155\x73", Constants::wcwmcocqaeiwwuss)) { $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\x72\145\x67\x69\x73\x74\x65\x72\137\163\x68\x6f\162\x74\143\x6f\144\145\x73", [$this, "\x72\x65\147\x69\x73\x74\x65\162"]); } } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
