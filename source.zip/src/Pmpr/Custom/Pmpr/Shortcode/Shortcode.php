<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f0c5eaefc02             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if (!($wksoawcgagcgoask = $this->mqucqomkmisceawy("\141\144\x76\x61\156\143\145\144\x2d\143\155\163"))) { goto foeeqckqsyockkak; } $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\145\x67\x69\163\164\x65\x72\137\163\150\x6f\x72\x74\143\157\144\x65\163", [$this, "\162\145\147\151\163\164\145\x72"]); foeeqckqsyockkak: } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
