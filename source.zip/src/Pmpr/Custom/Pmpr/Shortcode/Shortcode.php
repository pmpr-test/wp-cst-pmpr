<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ba68887             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Custom\Pmpr\Container; class Shortcode extends Container { public function aqyikqugcomoqqqi() { if ($wksoawcgagcgoask = $this->caokeucsksukesyo()->cqusmgskowmesgcg()->gsaceacmqiuqoouo("\141\144\166\x61\x6e\x63\x65\x64\x2d\143\155\163", Constants::wcwmcocqaeiwwuss)) { $this->cecaguuoecmccuse("{$wksoawcgagcgoask->aiqioscoyukqgsgw()}\x5f\162\x65\x67\x69\163\x74\145\x72\x5f\x73\150\x6f\x72\x74\143\157\x64\x65\x73", [$this, "\x72\145\147\151\163\x74\x65\x72"]); } } public function register($shortcodes = []) { return array_merge($shortcodes, [Who::symcgieuakksimmu(), Team::symcgieuakksimmu(), Service::symcgieuakksimmu()]); } }
