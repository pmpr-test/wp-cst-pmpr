<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c839bd07d61             |
    |_______________________________________|
*/
 namespace Pmpr\Custom\Pmpr\Shortcode; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; use Pmpr\Module\AdvancedCMS\Shortcode\Post\Post; class Service extends Post { const iwagoquioqacekqo = 'services'; public function gogaagekwoisaqgu() { $this->icon = IconInterface::gyycksgqsoogiayq; $this->title = __('Service', PR__CST__PMPR); } public function gkoiuyagqcoecigk() { parent::gkoiuyagqcoecigk(); add_shortcode("boiler_{$this->aakmagwggmkoiiyu()}_multiple", [$this, 'oseacqimecwggakw']); } public function ecwgiiuacoaokqkw() { $this->aucimgwswmgaocae($this->kwosaecaikgmoeyo()->mkksewyosgeumwsa(self::ymuegqgyuagyucws(Constants::qescuiwgsyuikume, __('Title', PR__CST__PMPR))->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::ckuwucygcwsiawms(self::iwagoquioqacekqo, __('Services', PR__CST__PMPR))->oikgogcweiiaocka()->eukmukacucooequu(['parent' => 0])->oeewiaacscgyamai('service')->iyouqgqicyqkiswi(6))->mkksewyosgeumwsa(self::sciaycsmsiekqueg(Constants::eqkeooqcsscoggia, __('Description', PR__CST__PMPR)))); } }
