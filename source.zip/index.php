<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda1c00115f             |
    |_______________________________________|
*/
 use Pmpr\Custom\Pmpr\Pmpr; Pmpr::symcgieuakksimmu();
